import { useState } from "react";

// ─── Change this to your deployed backend URL after deploying ─────────────────
const API_BASE = process.env.REACT_APP_API_URL || "http://localhost:3001";

// ─── Result Card Component ────────────────────────────────────────────────────
function ResultCard({ name, color, logo, siteUrl, result, loading }) {
  return (
    <div style={{
      background: "#fff", borderRadius: "16px",
      boxShadow: "0 2px 20px rgba(0,0,0,0.08)",
      padding: "20px", flex: 1, minWidth: "280px",
    }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "16px" }}>
        <div style={{
          width: 46, height: 46, borderRadius: "12px", background: color,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontWeight: 900, fontSize: "13px", color: "#fff", flexShrink: 0, letterSpacing: "-0.5px",
        }}>{logo}</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 800, fontSize: "15px", color: "#1e1b4b" }}>{name}</div>
          <a href={siteUrl} target="_blank" rel="noreferrer"
            style={{ fontSize: "11px", color: color, textDecoration: "none" }}>
            🔗 Official Website
          </a>
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div style={{ textAlign: "center", padding: "32px 0", color: "#94a3b8" }}>
          <div style={{ fontSize: "30px", marginBottom: "10px" }}>⏳</div>
          <div style={{ fontSize: "13px" }}>Searching... (20-30 sec)</div>
          <div style={{ fontSize: "11px", color: "#cbd5e1", marginTop: "4px" }}>
            Real browser open karyo chhe...
          </div>
        </div>
      )}

      {/* No result */}
      {!loading && result && !result.available && (
        <div>
          <div style={{
            background: "#fff9f0", border: "1px solid #fbd38d",
            borderRadius: "10px", padding: "14px", marginBottom: "12px",
          }}>
            <div style={{ fontSize: "22px", marginBottom: "4px" }}>❌</div>
            <div style={{ fontWeight: 700, color: "#92400e", fontSize: "14px" }}>
              Delivery Available Nathi
            </div>
            <div style={{ color: "#b45309", fontSize: "12px", marginTop: "4px" }}>
              {result.error ? `Error: ${result.error}` : "Aa PIN code mate network coverage mali nathi"}
            </div>
          </div>
          <a href={siteUrl} target="_blank" rel="noreferrer" style={{
            display: "block", textAlign: "center", background: color,
            color: "#fff", borderRadius: "8px", padding: "9px",
            textDecoration: "none", fontSize: "12px", fontWeight: 700,
          }}>
            Official site par verify karo →
          </a>
        </div>
      )}

      {/* Has result */}
      {!loading && result && result.available && result.data?.length > 0 && (
        <div>
          <div style={{
            background: "#f0fdf4", border: "1px solid #86efac",
            borderRadius: "10px", padding: "10px 14px", marginBottom: "12px",
            display: "flex", alignItems: "center", gap: "8px",
          }}>
            <span style={{ fontSize: "20px" }}>✅</span>
            <div>
              <div style={{ fontWeight: 800, color: "#166534", fontSize: "14px" }}>Delivery Available!</div>
              <div style={{ color: "#15803d", fontSize: "11px" }}>{result.data.length} branch{result.data.length > 1 ? "es" : ""} found</div>
            </div>
          </div>

          {result.data.map((row, i) => (
            <div key={i} style={{
              background: "#f8faff", border: "1px solid #e2e8f0",
              borderRadius: "10px", padding: "14px",
              marginBottom: i < result.data.length - 1 ? "10px" : 0,
              fontSize: "13px", lineHeight: "1.9",
            }}>
              {Object.entries(row).filter(([, v]) => v?.trim()).map(([k, v]) => (
                <div key={k} style={{ display: "flex", gap: "8px" }}>
                  <span style={{ color: "#64748b", fontWeight: 700, minWidth: "110px", flexShrink: 0, fontSize: "12px" }}>
                    {k}
                  </span>
                  <span style={{ color: "#1e1b4b", fontWeight: 500 }}>{v}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      {/* Idle */}
      {!loading && !result && (
        <div style={{ textAlign: "center", padding: "28px 0", color: "#cbd5e1", fontSize: "13px" }}>
          PIN code enter karo ane Search click karo
        </div>
      )}
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [pin, setPin] = useState("");
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState("");
  const [tpc, setTpc] = useState(null);
  const [stc, setStc] = useState(null);
  const [apiError, setApiError] = useState("");

  const handleSearch = async () => {
    const p = pin.trim();
    if (!/^\d{6}$/.test(p)) {
      alert("Valid 6-digit PIN code enter karo");
      return;
    }

    setLoading(true);
    setSearched(p);
    setTpc(null);
    setStc(null);
    setApiError("");

    try {
      const res = await fetch(`${API_BASE}/api/check/${p}`);
      if (!res.ok) throw new Error(`Server error: ${res.status}`);
      const data = await res.json();
      setTpc(data.tpc);
      setStc(data.stc);
    } catch (err) {
      setApiError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(135deg, #dbeafe 0%, #ede9fe 100%)",
      fontFamily: "'Segoe UI', Tahoma, sans-serif",
      padding: "28px 16px",
    }}>
      <div style={{ maxWidth: "860px", margin: "0 auto" }}>

        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: "28px" }}>
          <div style={{ fontSize: "44px", marginBottom: "8px" }}>📦</div>
          <h1 style={{ fontSize: "26px", fontWeight: 900, color: "#1e1b4b", margin: "0 0 6px" }}>
            Courier Network Checker
          </h1>
          <p style={{ color: "#64748b", fontSize: "13px", margin: 0 }}>
            PIN code enter karo — Shree Tirupati & TPC India banne nu real-time result ek jagya par
          </p>
        </div>

        {/* Search */}
        <div style={{
          background: "#fff", borderRadius: "16px", padding: "20px 24px",
          boxShadow: "0 4px 24px rgba(0,0,0,0.07)", marginBottom: "20px",
          display: "flex", gap: "12px", alignItems: "center", flexWrap: "wrap",
        }}>
          <input
            type="text" inputMode="numeric"
            value={pin}
            onChange={e => setPin(e.target.value.replace(/\D/g, "").slice(0, 6))}
            onKeyDown={e => e.key === "Enter" && !loading && handleSearch()}
            placeholder="6-digit PIN code enter karo..."
            maxLength={6}
            disabled={loading}
            style={{
              flex: 1, minWidth: "180px", border: "2px solid #e2e8f0",
              borderRadius: "10px", padding: "13px 18px",
              fontSize: "22px", fontWeight: 700, letterSpacing: "5px",
              outline: "none", color: "#1e1b4b",
              background: loading ? "#f8faff" : "#fff",
            }}
          />
          <button
            onClick={handleSearch}
            disabled={loading}
            style={{
              background: loading ? "#94a3b8" : "linear-gradient(135deg, #4f46e5, #7c3aed)",
              color: "#fff", border: "none", borderRadius: "10px",
              padding: "13px 32px", fontSize: "16px", fontWeight: 700,
              cursor: loading ? "not-allowed" : "pointer",
              whiteSpace: "nowrap",
            }}
          >
            {loading ? "⏳ Searching..." : "🔍 Search"}
          </button>
        </div>

        {/* API Error */}
        {apiError && (
          <div style={{
            background: "#fff5f5", border: "1px solid #fed7d7", borderRadius: "10px",
            padding: "14px 18px", marginBottom: "16px", color: "#c53030", fontSize: "13px",
          }}>
            ⚠️ <strong>Server Error:</strong> {apiError}
            <br />
            <span style={{ fontSize: "11px", color: "#e53e3e" }}>
              Backend server chal rahi chhe ke nahi check karo. README.md juo.
            </span>
          </div>
        )}

        {/* Result label */}
        {searched && !loading && (
          <div style={{ textAlign: "center", marginBottom: "14px", color: "#475569", fontSize: "13px" }}>
            PIN <strong style={{ color: "#4f46e5", fontSize: "17px", letterSpacing: "2px" }}>{searched}</strong> mate result:
          </div>
        )}

        {/* Cards */}
        <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
          <ResultCard
            name="Shree Tirupati Courier"
            color="#dc2626"
            logo="ST"
            siteUrl="http://www.shreetirupaticourier.net/network.aspx"
            result={stc}
            loading={loading}
          />
          <ResultCard
            name="TPC India — Professional Couriers"
            color="#1d4ed8"
            logo="TPC"
            siteUrl="https://www.tpcindia.com/Network.aspx"
            result={tpc}
            loading={loading}
          />
        </div>

        {/* How it works */}
        <div style={{
          marginTop: "20px", background: "#fff", borderRadius: "12px",
          padding: "16px 20px", boxShadow: "0 1px 10px rgba(0,0,0,0.05)",
          fontSize: "12px", color: "#64748b", lineHeight: "1.8"
        }}>
          <strong style={{ color: "#1e1b4b" }}>⚡ Aavu kevi rite kame chhe?</strong><br />
          Backend server real Chrome browser khole chhe, PIN type kare chhe, ane result scrape kare chhe.
          Search 20-30 seconds lagse. <strong>First search time thodi vaar lagse</strong> (browser warm-up).
        </div>

        <div style={{ textAlign: "center", marginTop: "14px", color: "#94a3b8", fontSize: "11px" }}>
          Powered by Node.js + Puppeteer • Data from official courier websites
        </div>
      </div>
    </div>
  );
}
