# 📦 Courier Network Checker

PIN code enter karo — Shree Tirupati Courier & TPC India banne nu result ek jagya par juo.

---

## 🏗️ Project Structure

```
courier-checker/
├── backend/          ← Node.js + Puppeteer API server
│   ├── server.js
│   └── package.json
└── frontend/         ← React web app
    ├── src/
    │   ├── App.jsx
    │   └── index.js
    ├── public/
    │   └── index.html
    └── package.json
```

---

## 🚀 Deploy Karvanu Step-by-Step

### STEP 1 — Railway par Backend Deploy karo (FREE)

> Railway best chhe Puppeteer/Chrome mate. Render.com pan chhe pan Chrome support limited chhe.

1. **Railway account banavo:** https://railway.app
   - GitHub account thi login karo

2. **GitHub par code upload karo:**
   - https://github.com/new — new repository banavo
   - Name: `courier-checker-backend`
   - `courier-checker/backend/` folder ni files upload karo:
     - `server.js`
     - `package.json`

3. **Railway par deploy karo:**
   - Railway dashboard → "New Project" → "Deploy from GitHub repo"
   - Tamara `courier-checker-backend` repo select karo
   - Railway automatic detect karse ke Node.js project chhe
   - Deploy thase — 3-5 minutes lagse (Puppeteer + Chrome install thase)

4. **Environment variables set karo (Railway dashboard → Variables):**
   ```
   PORT = 3001
   PUPPETEER_SKIP_CHROMIUM_DOWNLOAD = false
   ```

5. **Railway thi URL melo:**
   - Deploy thay pachhi Railway ek URL aapse jeva ke:
   - `https://courier-checker-backend-production.up.railway.app`
   - Aa URL note karo — frontend mate joiye

6. **Test karo browser ma:**
   ```
   https://YOUR-RAILWAY-URL/health
   ```
   Response aavvu joiye: `{"status":"ok"}`

   ```
   https://YOUR-RAILWAY-URL/api/check/396050
   ```
   Result aavse (30 sec lagse first time).

---

### STEP 2 — Netlify par Frontend Deploy karo (FREE)

1. **Frontend ma backend URL set karo:**
   - `courier-checker/frontend/` folder kholo
   - `.env` file banavo:
   ```
   REACT_APP_API_URL=https://YOUR-RAILWAY-URL
   ```
   (Railway URL thi replace karo)

2. **Build karo (local ma):**
   ```bash
   cd courier-checker/frontend
   npm install
   npm run build
   ```
   `build/` folder banashe.

3. **Netlify par deploy karo:**
   - https://netlify.com → login karo
   - "Add new site" → "Deploy manually"
   - `build/` folder drag & drop karo
   - Deploy thase — URL malshe jeva ke:
   - `https://courier-checker-xyz.netlify.app`

---

## 💻 Local ma Test Karvo (Computer par)

### Prerequisites
- Node.js 18+ install hovu joie: https://nodejs.org

### Backend chalu karo:
```bash
cd courier-checker/backend
npm install
node server.js
```
Output: `✅ Courier Checker API running on http://localhost:3001`

### Frontend chalu karo (nava terminal ma):
```bash
cd courier-checker/frontend
npm install
npm start
```
Browser automatic khuleshe: http://localhost:3000

---

## 🧪 API Directly Test Karvo

Backend chal rahi hoy to browser ma aata type karo:

```
http://localhost:3001/health
http://localhost:3001/api/check/395003
http://localhost:3001/api/check/400001
```

---

## ⚠️ Important Notes

- **First search 30-40 sec lagse** — Puppeteer Chrome browser open kare chhe
- **Subsequent searches faster** — browser warm raheshe
- Railway free plan ma **500 hours/month** milse — plenty chhe
- Netlify free plan ma **unlimited** frontend hosting

---

## 🔧 Troubleshooting

**Railway deploy fail thay?**
- `package.json` ma `"engines": {"node": ">=18.0.0"}` chhe ke check karo
- Railway logs juo: Dashboard → Deployments → View Logs

**"Cannot connect to backend" error?**
- Railway URL correct chhe ke check karo
- `/health` endpoint test karo
- CORS error hoy to Railway ma `FRONTEND_URL` variable add karo

**Puppeteer Chrome install fail?**
Railway automatically Chrome install kare chhe. Jao fail thay to Railway ma add karo:
```
PUPPETEER_EXECUTABLE_PATH=/usr/bin/google-chrome-stable
```

---

## 📞 Support

Koi problem hoy to screenshot laine poochho!
